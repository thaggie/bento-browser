yarn remove "electron" "electron-packager" "eslint-config-prettier" "eslint-plugin-prettier" "prettier" "electron-default-menu" "isomorphic-fetch"
yarn add "electron" "electron-packager" "eslint-config-prettier" "eslint-plugin-prettier" "prettier" "electron-default-menu" "isomorphic-fetch"
